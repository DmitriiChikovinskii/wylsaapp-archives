//
// Created by Dmitrii Space on 2019-07-01.
// Copyright (c) 2019 Dmitrii Space. All rights reserved.
//

struct FeedCardViewModel {
    let info: String
    let title: String
    let shortDescription: String
    let imageName: String
}
