//
// Created by Dmitrii Space on 2019-07-08.
// Copyright (c) 2019 Dmitrii Space. All rights reserved.
//

import UIKit

enum Styles {
    enum Color {
        static let appGreen: UIColor = .rgba(50, 160, 97)
    }
}
