//
// Created by Dmitrii Space on 2019-07-12.
// Copyright (c) 2019 Dmitrii Space. All rights reserved.
//

import Foundation

enum Localization {
    static let feed = "Лента"
    static let prize = "Конкурсы"
    static let video = "Видео"
    static let thumbsUp = "Годнота"
    static let podcasts = "Подкасты"

    static let loginTitle = "Авторизация"
    static let loginButton = "Войти"
    static let closeButton = "Закрыть"

}
