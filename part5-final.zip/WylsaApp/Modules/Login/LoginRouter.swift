//
//  LoginRouter.swift
//  WylsaApp
//
//  Created by Dmitrii Space on 09.03.2020.
//    Copyright © 2020 Dmitrii Space. All rights reserved.
//

import UIKit

final class LoginRouter {
}

extension LoginRouter: LoginRouterInput {
}
